function dy = Zustandsform(t,y,m,d,c,f)

dy=[y(2);
    1/m*(f-d*y(2)-c*y(1))];

end