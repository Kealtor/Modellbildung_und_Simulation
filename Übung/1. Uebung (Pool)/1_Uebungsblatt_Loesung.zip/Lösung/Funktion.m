function [mittelwert,summe] = Funktion(a,b,c)

mittelwert=(a+b+c)/3;
summe=a+b+c;

end